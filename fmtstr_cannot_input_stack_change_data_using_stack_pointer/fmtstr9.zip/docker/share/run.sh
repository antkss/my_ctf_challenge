#!/bin/sh

cd /home/user
socat tcp-listen:9999,fork,reuseaddr exec:./fmtstr9 2>/dev/null