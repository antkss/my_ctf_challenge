#!/bin/sh

sudo apt install -y docker.io
sudo docker build . -t fmtstr9
sudo docker run --rm -p 9999:9999 -it fmtstr9