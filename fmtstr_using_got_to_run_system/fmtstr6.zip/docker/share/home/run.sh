#!/bin/sh

socat tcp-listen:9996,fork,reuseaddr exec:./fmtstr6 2>/dev/null