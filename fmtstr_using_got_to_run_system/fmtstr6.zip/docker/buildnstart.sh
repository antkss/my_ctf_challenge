#!/bin/sh

sudo apt install docker.io
sudo docker build . -t fmtstr6 && sudo docker run -d --rm -p 9996:9996 -it fmtstr6